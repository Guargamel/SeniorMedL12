<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\MedicineRequest;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class MedicineRequestController extends Controller
{
    /**
     * Display a listing of medicine requests
     */
    public function index(Request $request)
    {
        try {
            $user = Auth::user();

            if ($user->hasRole('senior-citizen')) {
                $requests = MedicineRequest::with(['medicine', 'reviewer'])
                    ->where('user_id', $user->id)
                    ->orderByDesc('created_at')
                    ->get();
            } else {
                $requests = MedicineRequest::with(['medicine', 'user.seniorProfile', 'reviewer'])
                    ->orderByDesc('created_at')
                    ->get();
            }

            // ✅ return consistent shape for Flutter
            return response()->json([
                'data' => $requests
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to fetch medicine requests: ' . $e->getMessage());
            return response()->json([
                'message' => 'Failed to fetch requests',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a new medicine request (Senior Citizens only)
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'medicine_id'        => ['required', 'integer', 'exists:medicines,id'],
            'quantity'           => ['required', 'integer', 'min:1'],
            'reason'             => ['nullable', 'string'],
            'prescription_path'  => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
        ]);

        $path = null;
        if ($request->hasFile('prescription_path')) {
            $path = $request->file('prescription_path')->store('prescriptions', 'public');
        }

        $req = MedicineRequest::create([
            'user_id' => auth()->id(),
            'medicine_id' => $validated['medicine_id'],
            'quantity' => $validated['quantity'],
            'reason' => $validated['reason'] ?? null,
            'prescription_path' => $path,
            'status' => 'pending',
        ]);

        $req->load('medicine', 'reviewer');

        return response()->json([
            'data' => $req
        ], 201);
    }

    /**
     * Display a specific medicine request
     */
    public function show($id)
    {
        try {
            $user = Auth::user();

            $mr = MedicineRequest::with(['medicine', 'user.seniorProfile', 'reviewer'])
                ->findOrFail($id);

            if ($user->hasRole('senior-citizen') && $mr->user_id !== $user->id) {
                return response()->json(['message' => 'Unauthorized'], 403);
            }

            return response()->json(['data' => $mr]);
        } catch (\Exception $e) {
            Log::error('Failed to fetch medicine request: ' . $e->getMessage());
            return response()->json([
                'message' => 'Failed to fetch request',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Review a medicine request (Staff/Super-Admin only)
     */
    public function review(Request $request, $id)
    {
        try {
            $validated = $request->validate([
                'status' => 'required|in:approved,declined',
                // ✅ your DB column is notes
                'notes' => 'nullable|string|max:2000',
                // ✅ accept old key too (optional)
                'review_notes' => 'nullable|string|max:2000',
            ]);

            $mr = MedicineRequest::findOrFail($id);

            if ($mr->status !== 'pending') {
                return response()->json([
                    'message' => 'This request has already been reviewed'
                ], 400);
            }

            $reason = $validated['notes']
                ?? $validated['review_notes']
                ?? null;

            $mr->update([
                'status' => $validated['status'],
                'reviewed_by' => Auth::id(),
                'reviewed_at' => now(),
                'notes' => $reason, // ✅ store admin reason here
            ]);

            $mr->load('medicine', 'user', 'reviewer');

            try {
                $this->notifySeniorCitizen($mr);
            } catch (\Exception $e) {
                Log::error('Failed to send notification: ' . $e->getMessage());
            }

            return response()->json([
                'message' => 'Request ' . $validated['status'] . ' successfully',
                'data' => $mr
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to review request: ' . $e->getMessage());
            return response()->json([
                'message' => 'Failed to review request',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete a medicine request (only pending requests by the requester)
     */
    public function destroy($id)
    {
        try {
            $user = Auth::user();
            $mr = MedicineRequest::findOrFail($id);

            $isAdminOrStaff = $user->hasAnyRole(['super-admin', 'staff']);

            // Seniors can only delete their own pending requests
            if (!$isAdminOrStaff) {
                if ($mr->user_id !== $user->id) {
                    return response()->json(['message' => 'Unauthorized'], 403);
                }
                if ($mr->status !== 'pending') {
                    return response()->json(['message' => 'Cannot delete reviewed requests'], 400);
                }
            }

            // Always clean up prescription image from storage
            if ($mr->prescription_path && Storage::disk('public')->exists($mr->prescription_path)) {
                Storage::disk('public')->delete($mr->prescription_path);
            }

            $mr->delete();

            return response()->json(['message' => 'Request deleted successfully']);
        } catch (\Exception $e) {
            Log::error('Failed to delete request: ' . $e->getMessage());
            return response()->json([
                'message' => 'Failed to delete request',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function pendingCount()
    {
        try {
            $count = MedicineRequest::where('status', 'pending')->count();
            return response()->json(['count' => $count]);
        } catch (\Exception $e) {
            Log::error('Failed to get pending count: ' . $e->getMessage());
            return response()->json(['count' => 0]);
        }
    }

    private function notifySeniorCitizen(MedicineRequest $mr)
    {
        Notification::create([
            'user_id' => $mr->user_id,
            'type' => 'request_' . $mr->status,
            'title' => 'Request ' . ucfirst($mr->status),
            'message' => 'Your request for ' . $mr->medicine->generic_name . ' has been ' . $mr->status,
            'data' => json_encode([
                'request_id' => $mr->id,
                'medicine_name' => $mr->medicine->generic_name,
                'status' => $mr->status,
                'notes' => $mr->notes, // ✅ include notes
            ]),
            'read_at' => null
        ]);
    }
}
