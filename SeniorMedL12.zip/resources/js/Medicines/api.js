/**
 * Thin re-export so pages in /Medicines can import apiFetch consistently.
 * Your real helper should live at: resources/js/api.js
 */
export { apiFetch } from "../api";
