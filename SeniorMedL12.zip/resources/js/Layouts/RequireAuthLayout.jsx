import React, { useEffect, useState } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import Layout from "./HeaderLayout";
import SeniorLayout from "./SeniorLayout";
import { fetchCurrentUser, logout as apiLogout } from "../utils/auth";
import { UserContext } from "../Components/UserContext";

export default function RequireAuthLayout() {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [errors, setErrors] = useState([]);
    const location = useLocation();
    const navigate = useNavigate();

    useEffect(() => {
        let alive = true;

        (async () => {
            setLoading(true);
            setErrors([]);

            const u = await fetchCurrentUser();
            if (!alive) return;

            setUser(u);
            setLoading(false);
        })();

        return () => {
            alive = false;
        };
    }, []);

    const handleLogout = async () => {
        setErrors([]);
        try {
            await apiLogout();
            setUser(null);
            navigate("/login", { replace: true });
        } catch (e) {
            console.error("Logout error:", e);
            setErrors([e?.message || "Logout failed"]);
            setUser(null);
            navigate("/login", { replace: true });
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-4 border-gray-300 border-t-blue-600 mx-auto mb-4"></div>
                    <p className="text-gray-600">Loading...</p>
                </div>
            </div>
        );
    }

    if (!user) {
        return <Navigate to="/login" replace state={{ from: location.pathname }} />;
    }

    // Helper: get role names from Spatie roles array, with fallback to legacy role_id
    const LEGACY_ROLE_MAP = { 1: 'staff', 2: 'super-admin', 3: 'staff', 4: 'senior-citizen' };
    const userRoleNames = Array.isArray(user?.roles) && user.roles.length > 0
        ? user.roles.map(r => r.name)
        : (user?.role_id ? [LEGACY_ROLE_MAP[user.role_id]].filter(Boolean) : []);

    const isSeniorCitizen = userRoleNames.includes('senior-citizen');
    const isAdminOrStaff = userRoleNames.some(r => ['super-admin', 'staff'].includes(r));

    // If user has no recognized role at all, redirect to unauthorized
    if (!isAdminOrStaff && !isSeniorCitizen) {
        return <Navigate to="/unauthorized" replace />;
    }

    // Use SeniorLayout for senior citizens, regular Layout for admin/staff
    const LayoutComponent = isAdminOrStaff ? Layout : SeniorLayout;

    return (
        <UserContext.Provider value={{ user, userRoleNames }}>
            <LayoutComponent user={user} errors={errors} handleLogout={handleLogout} />
        </UserContext.Provider>
    );
}
