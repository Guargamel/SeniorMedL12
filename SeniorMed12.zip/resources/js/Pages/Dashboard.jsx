// resources/js/Dashboard/Index.jsx  (or wherever your router imports it from)
import React from "react";
import DashboardCards from "../Views/DashboardCards.jsx";

export default function Dashboard() {
    return (
        <div>
            <DashboardCards />
        </div>
    );
}
