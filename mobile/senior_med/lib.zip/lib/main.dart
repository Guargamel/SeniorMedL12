import 'package:flutter/material.dart';
import 'router/app_router.dart';

void main() {
  runApp(const SeniorMedApp());
}

class SeniorMedApp extends StatelessWidget {
  const SeniorMedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: "SeniorMed",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.deepPurple,
      ),
      routerConfig: AppRouter.router,
    );
  }
}
