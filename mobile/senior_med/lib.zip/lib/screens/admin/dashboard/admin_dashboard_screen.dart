import 'package:flutter/material.dart';

import '../../../services/api_service.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  Map<String, dynamic>? summary;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final res = await ApiService.instance.dio.get("/dashboard/summary");
      if (res.statusCode != 200) throw Exception("${res.statusCode}: ${res.data}");
      setState(() => summary = Map<String, dynamic>.from(res.data));
    } catch (e) {
      setState(() => error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = summary;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Dashboard"),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: error != null
            ? Text(error!, style: const TextStyle(color: Colors.red))
            : s == null
                ? const Center(child: CircularProgressIndicator())
                : ListView(
                    children: [
                      _StatCard(title: "Total Medicines", value: "${s["total_medicines"] ?? "-"}", icon: Icons.medication),
                      _StatCard(title: "Low Stock", value: "${s["low_stock_count"] ?? "-"}", icon: Icons.warning_amber),
                      _StatCard(title: "Expiring Soon", value: "${s["expiring_count"] ?? "-"}", icon: Icons.schedule),
                      _StatCard(title: "Total Seniors", value: "${s["total_seniors"] ?? "-"}", icon: Icons.elderly),
                      const SizedBox(height: 12),
                    ],
                  ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _StatCard({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Icon(icon, size: 28),
            const SizedBox(width: 12),
            Expanded(child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
            Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }
}
