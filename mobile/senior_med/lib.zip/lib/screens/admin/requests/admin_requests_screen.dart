import 'package:flutter/material.dart';
import '../../../services/api_service.dart';

class AdminRequestsScreen extends StatefulWidget {
  const AdminRequestsScreen({super.key});

  @override
  State<AdminRequestsScreen> createState() => _AdminRequestsScreenState();
}

class _AdminRequestsScreenState extends State<AdminRequestsScreen> {
  bool loading = true;
  String? error;
  List<dynamic> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      // For seniors this endpoint returns own requests; for staff/admin it might return all (depending controller)
      final res = await ApiService.instance.dio.get("/medicine-requests");
      if (res.statusCode != 200) throw Exception("${res.statusCode}: ${res.data}");
      final data = res.data;
      final list = (data is Map && data["data"] is List) ? data["data"] as List : (data is List ? data : []);
      setState(() => items = list);
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Requests"),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text(error!, style: const TextStyle(color: Colors.red)))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: items.length,
                  itemBuilder: (_, i) {
                    final r = items[i] as Map;
                    final med = r["medicine"] is Map ? r["medicine"] as Map : null;
                    return Card(
                      child: ListTile(
                        leading: const Icon(Icons.assignment),
                        title: Text(med?["generic_name"]?.toString() ?? "Request #${r["id"]}"),
                        subtitle: Text("Status: ${r["status"] ?? "-"} • ${r["created_at"] ?? ""}"),
                      ),
                    );
                  },
                ),
    );
  }
}
