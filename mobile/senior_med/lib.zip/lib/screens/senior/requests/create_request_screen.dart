import 'package:flutter/material.dart';
import '../../../services/api_service.dart';

class CreateRequestScreen extends StatefulWidget {
  final int? medicineId;
  final String? medicineLabel;

  const CreateRequestScreen({super.key, this.medicineId, this.medicineLabel});

  @override
  State<CreateRequestScreen> createState() => _CreateRequestScreenState();
}

class _CreateRequestScreenState extends State<CreateRequestScreen> {
  int? medicineId;
  final qtyCtrl = TextEditingController(text: "1");
  final notesCtrl = TextEditingController();

  bool loading = false;
  String? error;

  List<dynamic> medicines = [];

  @override
  void initState() {
    super.initState();
    medicineId = widget.medicineId;
    _loadMedicines();
  }

  Future<void> _loadMedicines() async {
    try {
      final res = await ApiService.instance.dio.get("/medicines");
      if (res.statusCode != 200) throw Exception("${res.statusCode}: ${res.data}");
      final data = res.data;
      medicines = (data is Map && data["data"] is List) ? data["data"] as List : (data is List ? data : []);
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  Future<void> _submit() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      if (medicineId == null) throw Exception("Please select a medicine.");

      final qty = int.tryParse(qtyCtrl.text.trim()) ?? 1;

      // Adjust payload keys to match your Laravel MedicineRequestController::store
      final res = await ApiService.instance.dio.post("/medicine-requests", data: {
        "medicine_id": medicineId,
        "quantity": qty,
        "notes": notesCtrl.text.trim(),
      });

      if (res.statusCode != 200 && res.statusCode != 201) {
        throw Exception("Create failed (${res.statusCode}): ${res.data}");
      }

      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    qtyCtrl.dispose();
    notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("New Request")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            DropdownButtonFormField<int>(
              value: medicineId,
              decoration: const InputDecoration(
                labelText: "Medicine",
                border: OutlineInputBorder(),
              ),
              items: medicines.map((m) {
                final mm = m as Map;
                return DropdownMenuItem(
                  value: (mm["id"] ?? 0) as int,
                  child: Text(mm["generic_name"]?.toString() ?? "Medicine"),
                );
              }).toList(),
              onChanged: (v) => setState(() => medicineId = v),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: qtyCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Quantity",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: notesCtrl,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: "Notes (optional)",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            if (error != null) ...[
              Text(error!, style: const TextStyle(color: Colors.red)),
              const SizedBox(height: 10),
            ],
            SizedBox(
              height: 48,
              child: ElevatedButton(
                onPressed: loading ? null : _submit,
                child: loading
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text("Submit Request"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
