import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import '../../../services/api_service.dart';
import '../../../core/request_events.dart';
import 'create_request_screen.dart';

class MyRequestsScreen extends StatefulWidget {
  const MyRequestsScreen({super.key});

  @override
  State<MyRequestsScreen> createState() => _MyRequestsScreenState();
}

class _MyRequestsScreenState extends State<MyRequestsScreen>
    with WidgetsBindingObserver {
  bool loading = true;
  String? error;
  List<dynamic> items = [];

  Timer? _timer;
  bool _fetching = false;
  CancelToken? _cancelToken;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _load();

    RequestEvents.tick.addListener(_onRequestCreated);

    _startTimer();
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 60), (_) => _load());
  }

  void _stopTimer() {
    _timer?.cancel();
    _timer = null;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Stop polling when app is not active (prevents cut-off/empty responses)
    if (state == AppLifecycleState.resumed) {
      _startTimer();
      _load(); // optional refresh on return
    } else {
      _stopTimer();
      _cancelToken?.cancel("App in background");
    }
  }

  void _onRequestCreated() => _load();

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _stopTimer();
    _cancelToken?.cancel("Disposed");
    RequestEvents.tick.removeListener(_onRequestCreated);
    super.dispose();
  }

  Future<void> _load() async {
    if (!mounted) return;

    // prevent overlap
    if (_fetching) return;
    _fetching = true;

    // cancel previous in-flight request (just in case)
    _cancelToken?.cancel("New refresh");
    _cancelToken = CancelToken();

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final res = await ApiService.instance.dio.get(
        "/medicine-requests",
        cancelToken: _cancelToken,
        options: Options(
          responseType: ResponseType.json, // ensure Dio expects JSON
          headers: {"Accept": "application/json"},
        ),
      );

      if (res.statusCode != 200) {
        throw Exception("${res.statusCode}: ${res.data}");
      }

      final data = res.data;

      final list = (data is Map && data["data"] is List)
          ? data["data"] as List
          : (data is List ? data : const []);

      if (!mounted) return;
      setState(() => items = list);
    } on DioException catch (e) {
      if (CancelToken.isCancel(e)) {
        // ignore cancels (background/dispose/refresh)
        return;
      }
      if (!mounted) return;
      setState(() => error = e.message ?? e.toString());
    } catch (e) {
      if (!mounted) return;
      setState(() => error = e.toString());
    } finally {
      _fetching = false;
      if (!mounted) return;
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    // keep your UI below, we’ll improve the "reason" display in section 3
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Requests"),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final created = await Navigator.of(context).push<bool>(
            MaterialPageRoute(builder: (_) => const CreateRequestScreen()),
          );
          if (created == true) _load();
        },
        label: const Text("New Request"),
        icon: const Icon(Icons.add),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
          ? Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(error!, style: const TextStyle(color: Colors.red)),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: _load,
                icon: const Icon(Icons.refresh),
                label: const Text("Reload"),
              ),
            ],
          ),
        ),
      )
          : items.isEmpty
          ? Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text("No requests yet."),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: _load,
              icon: const Icon(Icons.refresh),
              label: const Text("Reload"),
            ),
          ],
        ),
      )
          : RefreshIndicator(
        onRefresh: _load,
        child: ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: items.length,
          itemBuilder: (_, i) {
            final r = items[i] as Map;
            final med =
            r["medicine"] is Map ? r["medicine"] as Map : null;

            final statusRaw = (r["status"] ?? "-").toString();
            final status = statusRaw.toLowerCase();
            final bool approved = status.contains('approved');
            final bool rejected =
                status.contains('rejected') ||
                    status.contains('declined');

            final Color statusColor = approved
                ? Colors.green
                : (rejected ? Colors.red : Colors.orange);

            final String statusLabel = approved
                ? 'APPROVED'
                : (rejected ? 'REJECTED' : 'PENDING');

            final notes = (r["notes"] ?? "").toString().trim();

            return Card(
              child: ListTile(
                leading: const Icon(Icons.assignment_turned_in),
                title: Text(med?["generic_name"]?.toString() ??
                    "Request #${r["id"]}"),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        const Text("Status: "),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: statusColor.withOpacity(0.12),
                            borderRadius:
                            BorderRadius.circular(999),
                            border: Border.all(
                                color:
                                statusColor.withOpacity(0.45)),
                          ),
                          child: Text(
                            statusLabel,
                            style: TextStyle(
                              color: statusColor,
                              fontWeight: FontWeight.w700,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                    if (notes.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text(
                        "Reason: $notes",
                        style: TextStyle(
                          color: rejected
                              ? Colors.red
                              : (approved
                              ? Colors.green
                              : Colors.black87),
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ],
                ),
                trailing: Text(
                  r["created_at"]?.toString() ?? "",
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
