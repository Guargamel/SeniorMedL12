import 'package:flutter/material.dart';

import '../senior/browse/browse_medicines_screen.dart';
import '../senior/requests/my_requests_screen.dart';
import '../senior/notifications/senior_notifications_screen.dart';
import '../common/profile_screen.dart';

import '../../services/notification_badge_service.dart';

class SeniorShell extends StatefulWidget {
  const SeniorShell({super.key});

  @override
  State<SeniorShell> createState() => _SeniorShellState();
}

class _SeniorShellState extends State<SeniorShell> {
  int index = 0;

  int _notifCount = 0;

  Future<void> _refreshBadge() async {
    try {
      final res = await NotificationBadgeService.getNewCount();
      if (!mounted) return;
      setState(() => _notifCount = res.count);
    } catch (_) {
      // Don't block UI if notifications fail.
    }
  }

  late final List<Widget> pages = [
    const BrowseMedicinesScreen(),
    const MyRequestsScreen(),
    SeniorNotificationsScreen(onSeenLatest: _refreshBadge),
    const ProfileScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _refreshBadge();
  }

  Widget _navIconWithBadge(IconData icon, int count) {
    if (count <= 0) return Icon(icon);

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Icon(icon),
        Positioned(
          right: -6,
          top: -6,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              count > 99 ? '99+' : '$count',
              style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) async {
          setState(() => index = i);
          // Refresh when the user navigates (new approvals may have created notifications).
          await _refreshBadge();
        },
        destinations: [
          const NavigationDestination(icon: Icon(Icons.search), label: "Browse"),
          const NavigationDestination(icon: Icon(Icons.assignment_turned_in), label: "My Requests"),
          NavigationDestination(icon: _navIconWithBadge(Icons.notifications, _notifCount), label: "Updates"),
          const NavigationDestination(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
    );
  }
}
